﻿using Microsoft.EntityFrameworkCore;
using KfzKonfiguratorApp.Models;

namespace KfzKonfiguratorApp.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Hersteller> Hersteller => Set<Hersteller>();
        public DbSet<Treibstoff> Treibstoffe => Set<Treibstoff>();
        public DbSet<Motor> Motoren => Set<Motor>();
        public DbSet<Option> Options => Set<Option>();
        public DbSet<Bestellung> Bestellungen => Set<Bestellung>();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
            var fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "kfz.db");
            optionsBuilder.UseSqlite($"Data Source={fullPath}");

            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            
            modelBuilder.Entity<Bestellung>()
                .HasMany(b => b.Options)
                .WithMany(o => o.Bestellungen)
                .UsingEntity<Dictionary<string, object>>(
                    "BestellungOptions",
                    j => j
                        .HasOne<Option>()
                        .WithMany()
                        .HasForeignKey("OptionId"),
                    j => j
                        .HasOne<Bestellung>()
                        .WithMany()
                        .HasForeignKey("BestellungId")
                );

            // =======================
            // Seeding 
            // =======================
            // Hersteller
            modelBuilder.Entity<Hersteller>().HasData(
                new Hersteller { Id = 1, Anzeigetext = "Volkswagen", Grundpreis = 15000m },
                new Hersteller { Id = 2, Anzeigetext = "Opel", Grundpreis = 20000m },
                new Hersteller { Id = 3, Anzeigetext = "BMW", Grundpreis = 30000m }
            );

            // Treibstoffe
            modelBuilder.Entity<Treibstoff>().HasData(
                new Treibstoff { Id = 1, Anzeigetext = "Hybrid", Umweltfreundlichkeitsklasse = 1 },
                new Treibstoff { Id = 2, Anzeigetext = "Benzin", Umweltfreundlichkeitsklasse = 2 },
                new Treibstoff { Id = 3, Anzeigetext = "Diesel", Umweltfreundlichkeitsklasse = 3 }
            );

            // Motoren 
            modelBuilder.Entity<Motor>().HasData(
                // Benzin
                new Motor { Id = 1, TreibstoffId = 2, Anzeigetext = "Benzin 1.6", Preis = 1500m },
                new Motor { Id = 2, TreibstoffId = 2, Anzeigetext = "Benzin 2.5", Preis = 5000m },

                // Diesel
                new Motor { Id = 3, TreibstoffId = 3, Anzeigetext = "Diesel 1.8", Preis = 2000m },
                new Motor { Id = 4, TreibstoffId = 3, Anzeigetext = "Diesel 3.5", Preis = 4000m },

                // Hybrid (mein eigenes Beispiel, da in der Übung nichts über den Hybrid erwähnt wird)
                new Motor { Id = 5, TreibstoffId = 1, Anzeigetext = "Hybrid 2.0 ", Preis = 6000m }
            );

            // Options
            modelBuilder.Entity<Option>().HasData(
                new Option { Id = 1, Anzeigetext = "Klimaanlage", Preis = 2000m },
                new Option { Id = 2, Anzeigetext = "Alufelgen", Preis = 1000m },
                new Option { Id = 3, Anzeigetext = "Navigation", Preis = 500m },
                new Option { Id = 4, Anzeigetext = "Subwoofer", Preis = 100m }
            );
        }
    }
}


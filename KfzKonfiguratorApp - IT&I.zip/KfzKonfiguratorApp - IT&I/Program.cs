﻿using KfzKonfiguratorApp.Data;
using KfzKonfiguratorApp.Models;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Text.RegularExpressions;

namespace KfzKonfiguratorApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Euro-Zeichen korrekt anzeigen
            Console.OutputEncoding = Encoding.UTF8;

            using var db = new AppDbContext();

            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n=== KFZ-Konfigurator App ===");
                Console.WriteLine("1) Neues Fahrzeug bestellen");
                Console.WriteLine("2) Bestehende Bestellung ändern");
                Console.WriteLine("3) Bestellung stornieren");
                Console.WriteLine("4) Beenden");
                Console.Write("Auswahl: ");
                var input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        NeuesFahrzeugBestellen(db);
                        break;
                    case "2":
                        BestellungAendern(db);
                        break;
                    case "3":
                        BestellungStornieren(db);
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Ungültige Eingabe!");
                        break;
                }
            }
        }

        static void NeuesFahrzeugBestellen(AppDbContext db)
        {
            // Kundendaten abfragen : Vorname,Nachname und Geburtsdatum
            Console.Write("Vorname: ");
            string vorname = Console.ReadLine() ?? "";
            Console.Write("Nachname: ");
            string nachname = Console.ReadLine() ?? "";
            Console.Write("Geburtsdatum (dd.MM.yyyy): ");
            DateTime geburtsdatum;
            while (!DateTime.TryParse(Console.ReadLine(), out geburtsdatum))
            {
                Console.Write("Ungültiges Datum. Bitte erneut eingeben (dd.MM.yyyy): ");
            }

            // 2) Hersteller auswählen
            var herstellerListe = db.Hersteller
                .ToList()
                .OrderBy(h => h.Grundpreis)
                .ToList();
            Console.WriteLine("\nBitte Hersteller wählen:");
            for (int i = 0; i < herstellerListe.Count; i++)
            {
                var h = herstellerListe[i];
                // Ausgabe mit Euro-Zeichen
                Console.WriteLine($"{i + 1}) {h.Anzeigetext} - Grundpreis {h.Grundpreis} €");
            }
            int herstellerIndex = HoleIndexVonBenutzer(herstellerListe.Count);

            // Treibstoff auswählen (Sortieruen nach Umweltfreundlichkeitsklasse)
            var treibstoffListe = db.Treibstoffe
                .ToList()
                .OrderBy(t => t.Umweltfreundlichkeitsklasse)
                .ToList();
            Console.WriteLine("\nBitte Treibstoff wählen:");
            for (int i = 0; i < treibstoffListe.Count; i++)
            {
                var t = treibstoffListe[i];
                Console.WriteLine($"{i + 1}) {t.Anzeigetext}");
            }
            int treibstoffIndex = HoleIndexVonBenutzer(treibstoffListe.Count);
            var gewaehlterTreibstoff = treibstoffListe[treibstoffIndex];

            // Motor auswählen (abhängig vom Treibstoff)
            var motorListe = db.Motoren
                .Where(m => m.TreibstoffId == gewaehlterTreibstoff.Id)
                .ToList()
                .OrderBy(m => m.Preis)
                .ToList();
            Console.WriteLine("\nBitte Motor wählen:");
            for (int i = 0; i < motorListe.Count; i++)
            {
                var motor = motorListe[i];
                Console.WriteLine($"{i + 1}) {motor.Anzeigetext} - {motor.Preis} €");
            }
            int motorIndex = HoleIndexVonBenutzer(motorListe.Count);

            // Farbe eingeben (nur gültiges Hex)
            Console.Write("\nBitte Farbe eingeben (z.B. #00FF00): ");
            string farbe = Console.ReadLine() ?? "";
            while (!IstGueltigeHexFarbe(farbe))
            {
                Console.Write("Farbe ungültig. Erneut eingeben (#RRGGBB): ");
                farbe = Console.ReadLine() ?? "";
            }

            // Options auswählen (Mehrfachauswahl, sortiert absteigend nach Preis)
            var optionListe = db.Options
                .ToList()
                .OrderByDescending(o => o.Preis)
                .ToList();
            Console.WriteLine("\nVerfügbare Optionen (Mehrfachauswahl, kommasepariert, z.B. 1,2):");
            for (int i = 0; i < optionListe.Count; i++)
            {
                var opt = optionListe[i];
                Console.WriteLine($"{i + 1}) {opt.Anzeigetext} - {opt.Preis} €");
            }
            Console.Write("Deine Wahl (oder leer, wenn keine): ");
            string optionEingabe = Console.ReadLine() ?? "";
            var gewaehlteOptionen = new List<Option>();
            if (!string.IsNullOrWhiteSpace(optionEingabe))
            {
                var teile = optionEingabe.Split(',', StringSplitOptions.RemoveEmptyEntries);
                foreach (var t in teile)
                {
                    if (int.TryParse(t, out int optIndex))
                    {
                        if (optIndex > 0 && optIndex <= optionListe.Count)
                        {
                            gewaehlteOptionen.Add(optionListe[optIndex - 1]);
                        }
                    }
                }
            }

            // Neue Bestellung erstellen und speichern
            var bestellung = new Bestellung
            {
                Vorname = vorname,
                Nachname = nachname,
                Geburtsdatum = geburtsdatum,
                HerstellerId = herstellerListe[herstellerIndex].Id,
                MotorId = motorListe[motorIndex].Id,
                Farbe = farbe,
                Options = gewaehlteOptionen
            };

            db.Bestellungen.Add(bestellung);
            db.SaveChanges();

            // Zusammenfassung ausgeben
            AusgabeBestellZusammenfassung(db, bestellung.Id);
        }

        static void BestellungAendern(AppDbContext db)
        {
            // S ist die erste Buchstabe vom Wort Suche (just a personal choice)
            Console.WriteLine("Bitte Bestellnummer eingeben oder (S) für Suche per Nachname + Geburtsdatum:");
            string input = Console.ReadLine() ?? "";

            Bestellung? bestellung = null;
            if (input.Equals("S", StringComparison.OrdinalIgnoreCase))
            {
                Console.Write("Nachname: ");
                string nachname = Console.ReadLine() ?? "";
                Console.Write("Geburtsdatum (dd.MM.yyyy): ");
                DateTime datum;
                while (!DateTime.TryParse(Console.ReadLine(), out datum))
                {
                    Console.Write("Ungültiges Datum. Bitte erneut eingeben (dd.MM.yyyy): ");
                }

                bestellung = db.Bestellungen
                    .Include(b => b.Options)
                    .FirstOrDefault(b => b.Nachname == nachname && b.Geburtsdatum == datum);
            }
            else
            {
                // Bestellnummer :ID
                if (int.TryParse(input, out int bestellId))
                {
                    bestellung = db.Bestellungen
                        .Include(b => b.Options)
                        .FirstOrDefault(b => b.Id == bestellId);
                }
            }

            if (bestellung == null)
            {
                Console.WriteLine("Bestellung wurde nicht gefunden.");
                return;
            }

            //  Hersteller, Motor, Farbe, Options können geändret werden
            // aber Vorname, Nachname, Geburtsdatum bleiben unverändert
            var herstellerListe = db.Hersteller
                .ToList()
                .OrderBy(h => h.Grundpreis)
                .ToList();
            Console.WriteLine("\nBitte neuen Hersteller wählen (oder ENTER, um alten zu behalten):");
            for (int i = 0; i < herstellerListe.Count; i++)
            {
                var h = herstellerListe[i];
                Console.WriteLine($"{i + 1}) {h.Anzeigetext} - {h.Grundpreis} €");
            }
            string herstellerEingabe = Console.ReadLine() ?? "";
            if (!string.IsNullOrWhiteSpace(herstellerEingabe))
            {
                int herstellerIndex = HoleIndexVonBenutzer(herstellerListe.Count, herstellerEingabe);
                bestellung.HerstellerId = herstellerListe[herstellerIndex].Id;
            }

            var aktuellerMotor = db.Motoren.Find(bestellung.MotorId);
            if (aktuellerMotor == null)
            {
                Console.WriteLine("Fehler: Aktueller Motor nicht gefunden.");
                return;
            }

            var motorListe = db.Motoren
                .Where(m => m.TreibstoffId == aktuellerMotor.TreibstoffId)
                .ToList()
                .OrderBy(m => m.Preis)
                .ToList();
            Console.WriteLine("\nBitte neuen Motor wählen (oder ENTER, um alten zu behalten):");
            for (int i = 0; i < motorListe.Count; i++)
            {
                var motor = motorListe[i];
                Console.WriteLine($"{i + 1}) {motor.Anzeigetext} - {motor.Preis} €");
            }
            string motorEingabe = Console.ReadLine() ?? "";
            if (!string.IsNullOrWhiteSpace(motorEingabe))
            {
                int motorIndex = HoleIndexVonBenutzer(motorListe.Count, motorEingabe);
                bestellung.MotorId = motorListe[motorIndex].Id;
            }

            Console.WriteLine($"\nAktuelle Farbe: {bestellung.Farbe}");
            Console.Write("Neue Farbe eingeben (oder ENTER, um alte zu behalten): ");
            string farbeNeu = Console.ReadLine() ?? "";
            if (!string.IsNullOrWhiteSpace(farbeNeu))
            {
                while (!IstGueltigeHexFarbe(farbeNeu))
                {
                    Console.Write("Farbe ungültig. Erneut eingeben (#RRGGBB): ");
                    farbeNeu = Console.ReadLine() ?? "";
                }
                bestellung.Farbe = farbeNeu;
            }

            // Optionen neu setzen (oder ENTER, um alte zu behalten)
            var optionListe = db.Options
                .ToList()
                .OrderByDescending(o => o.Preis)
                .ToList();
            Console.WriteLine("\nOptionen neu wählen (z.B. 1,3) oder ENTER, um nicht zu ändern:");
            for (int i = 0; i < optionListe.Count; i++)
            {
                var opt = optionListe[i];
                Console.WriteLine($"{i + 1}) {opt.Anzeigetext} - {opt.Preis} €");
            }
            string optionEingabe = Console.ReadLine() ?? "";
            if (!string.IsNullOrWhiteSpace(optionEingabe))
            {
                bestellung.Options?.Clear();
                var teile = optionEingabe.Split(',', StringSplitOptions.RemoveEmptyEntries);
                foreach (var t in teile)
                {
                    if (int.TryParse(t, out int optIndex) && optIndex > 0 && optIndex <= optionListe.Count)
                    {
                        bestellung.Options?.Add(optionListe[optIndex - 1]);
                    }
                }
            }

            db.SaveChanges();
            Console.WriteLine("\nBestellung wurde erfolgreich geändert:");
            AusgabeBestellZusammenfassung(db, bestellung.Id);
        }

        static void BestellungStornieren(AppDbContext db)
        {
            // S ist die erste Buchstabe von Suche (just a personal choice)
            Console.WriteLine("Bitte Bestellnummer eingeben oder (S) für Suche per Nachname + Geburtsdatum:");
            string input = Console.ReadLine() ?? "";

            Bestellung? bestellung = null;
            if (input.Equals("S", StringComparison.OrdinalIgnoreCase))
            {
                Console.Write("Nachname: ");
                string nachname = Console.ReadLine() ?? "";
                Console.Write("Geburtsdatum (dd.MM.yyyy): ");
                DateTime datum;
                while (!DateTime.TryParse(Console.ReadLine(), out datum))
                {
                    Console.Write("Ungültiges Datum. Bitte erneut eingeben (dd.MM.yyyy): ");
                }

                bestellung = db.Bestellungen
                    .FirstOrDefault(b => b.Nachname == nachname && b.Geburtsdatum == datum);
            }
            else
            {
                if (int.TryParse(input, out int bestellId))
                {
                    bestellung = db.Bestellungen
                        .FirstOrDefault(b => b.Id == bestellId);
                }
            }

            if (bestellung == null)
            {
                Console.WriteLine("Bestellung nicht gefunden!");
                return;
            }

            db.Bestellungen.Remove(bestellung);
            db.SaveChanges();
            Console.WriteLine("Bestellung wurde erfolgreich storniert (gelöscht).");
        }

        // =======================
        // Hilfsfunktionen
        // =======================
        static int HoleIndexVonBenutzer(int maxAnzahl, string? vorgabe = null)
        {
            int index;
            if (!string.IsNullOrEmpty(vorgabe))
            {
                while (!int.TryParse(vorgabe, out index) || index < 1 || index > maxAnzahl)
                {
                    Console.Write($"Bitte Zahl zwischen 1 und {maxAnzahl} eingeben: ");
                    vorgabe = Console.ReadLine();
                }
                return index - 1;
            }

            string? eingabe = Console.ReadLine();
            while (!int.TryParse(eingabe, out index) || index < 1 || index > maxAnzahl)
            {
                Console.Write($"Bitte Zahl zwischen 1 und {maxAnzahl} eingeben: ");
                eingabe = Console.ReadLine();
            }
            return index - 1;
        }

        static bool IstGueltigeHexFarbe(string farbe)
        {
            // Einfache Regex für # + 6 Hex-Zeichen
            return Regex.IsMatch(farbe, "^#[0-9A-Fa-f]{6}$");
        }

        static void AusgabeBestellZusammenfassung(AppDbContext db, int bestellId)
        {
            var bestellung = db.Bestellungen
                .Include(b => b.Hersteller)
                .Include(b => b.Motor).ThenInclude(m => m.Treibstoff)
                .Include(b => b.Options)
                .FirstOrDefault(b => b.Id == bestellId);

            if (bestellung == null) return;

            // Preise berechnen
            decimal grundpreis = bestellung.Hersteller?.Grundpreis ?? 0;
            decimal motorpreis = bestellung.Motor?.Preis ?? 0;
            decimal optionsSumme = bestellung.Options?.Sum(o => o.Preis) ?? 0;
            decimal gesamt = grundpreis + motorpreis + optionsSumme;

            Console.WriteLine("\n=== Bestellungsübersicht ===");
            Console.WriteLine($"Bestellnummer: {bestellung.Id}");
            Console.WriteLine($"Kunde: {bestellung.Vorname} {bestellung.Nachname}, geb. {bestellung.Geburtsdatum:dd.MM.yyyy}");
            Console.WriteLine($"Hersteller: {bestellung.Hersteller?.Anzeigetext}");
            Console.WriteLine($"Treibstoff: {bestellung.Motor?.Treibstoff?.Anzeigetext}");
            Console.WriteLine($"Motor: {bestellung.Motor?.Anzeigetext}");
            Console.WriteLine($"Farbe: {bestellung.Farbe}");
            if (bestellung.Options != null && bestellung.Options.Any())
            {
                Console.WriteLine("Optionen: " + string.Join(", ", bestellung.Options.Select(o => o.Anzeigetext)));
            }
            else
            {
                Console.WriteLine("Optionen: Keine");
            }
            Console.WriteLine($"Gesamtpreis: {gesamt} €");
        }
    }
}

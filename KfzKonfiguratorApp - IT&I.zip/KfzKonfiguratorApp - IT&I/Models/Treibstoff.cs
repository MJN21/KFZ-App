﻿namespace KfzKonfiguratorApp.Models
{
    public class Treibstoff
    {
        public int Id { get; set; }
        public string Anzeigetext { get; set; } = string.Empty;
        public int Umweltfreundlichkeitsklasse { get; set; }
    }
}

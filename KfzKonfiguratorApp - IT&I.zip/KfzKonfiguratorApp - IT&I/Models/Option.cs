﻿namespace KfzKonfiguratorApp.Models
{
    public class Option
    {
        public int Id { get; set; }
        public string Anzeigetext { get; set; } = string.Empty;
        public decimal Preis { get; set; }

        // Eine Option kann in vielen Bestellungen verwendet werden,
        // und eine Bestellung kann mehrere Options enthalten.
        public ICollection<Bestellung>? Bestellungen { get; set; }
    }
}

﻿namespace KfzKonfiguratorApp.Models
{
    public class Bestellung
    {
        public int Id { get; set; }

        // Kunde
        public string Vorname { get; set; } = string.Empty;
        public string Nachname { get; set; } = string.Empty;
        public DateTime Geburtsdatum { get; set; }

        // Fahrzeug-Konfiguration
        public int HerstellerId { get; set; }
        public Hersteller? Hersteller { get; set; }

        public int MotorId { get; set; }
        public Motor? Motor { get; set; }

        // Farbe
        public string Farbe { get; set; } = string.Empty;

        // m:n-Beziehung zu Options: Eine Bestellung kann mehrere Options haben, und umgekehrt kann eine Option in mehreren Bestellungen vorkommen.
        public ICollection<Option>? Options { get; set; }
    }
}

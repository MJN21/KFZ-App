﻿namespace KfzKonfiguratorApp.Models
{
    public class Motor
    {
        public int Id { get; set; }

        
        public int TreibstoffId { get; set; }
        public Treibstoff? Treibstoff { get; set; }

        public string Anzeigetext { get; set; } = string.Empty;
        public decimal Preis { get; set; }
    }
}

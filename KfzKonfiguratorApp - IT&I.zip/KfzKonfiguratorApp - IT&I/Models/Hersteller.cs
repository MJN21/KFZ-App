﻿namespace KfzKonfiguratorApp.Models
{
    public class Hersteller
    {
        public int Id { get; set; }
        public string Anzeigetext { get; set; } = string.Empty;
        public decimal Grundpreis { get; set; }
    }
}

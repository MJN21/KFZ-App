﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KfzKonfiguratorApp.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Hersteller",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Anzeigetext = table.Column<string>(type: "TEXT", nullable: false),
                    Grundpreis = table.Column<decimal>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hersteller", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Options",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Anzeigetext = table.Column<string>(type: "TEXT", nullable: false),
                    Preis = table.Column<decimal>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Options", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Treibstoffe",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Anzeigetext = table.Column<string>(type: "TEXT", nullable: false),
                    Umweltfreundlichkeitsklasse = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Treibstoffe", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Motoren",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    TreibstoffId = table.Column<int>(type: "INTEGER", nullable: false),
                    Anzeigetext = table.Column<string>(type: "TEXT", nullable: false),
                    Preis = table.Column<decimal>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Motoren", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Motoren_Treibstoffe_TreibstoffId",
                        column: x => x.TreibstoffId,
                        principalTable: "Treibstoffe",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Bestellungen",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Vorname = table.Column<string>(type: "TEXT", nullable: false),
                    Nachname = table.Column<string>(type: "TEXT", nullable: false),
                    Geburtsdatum = table.Column<DateTime>(type: "TEXT", nullable: false),
                    HerstellerId = table.Column<int>(type: "INTEGER", nullable: false),
                    MotorId = table.Column<int>(type: "INTEGER", nullable: false),
                    Farbe = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bestellungen", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Bestellungen_Hersteller_HerstellerId",
                        column: x => x.HerstellerId,
                        principalTable: "Hersteller",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Bestellungen_Motoren_MotorId",
                        column: x => x.MotorId,
                        principalTable: "Motoren",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "BestellungOptions",
                columns: table => new
                {
                    BestellungId = table.Column<int>(type: "INTEGER", nullable: false),
                    OptionId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BestellungOptions", x => new { x.BestellungId, x.OptionId });
                    table.ForeignKey(
                        name: "FK_BestellungOptions_Bestellungen_BestellungId",
                        column: x => x.BestellungId,
                        principalTable: "Bestellungen",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BestellungOptions_Options_OptionId",
                        column: x => x.OptionId,
                        principalTable: "Options",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Hersteller",
                columns: new[] { "Id", "Anzeigetext", "Grundpreis" },
                values: new object[] { 1, "Volkswagen", 15000m });

            migrationBuilder.InsertData(
                table: "Hersteller",
                columns: new[] { "Id", "Anzeigetext", "Grundpreis" },
                values: new object[] { 2, "Opel", 20000m });

            migrationBuilder.InsertData(
                table: "Hersteller",
                columns: new[] { "Id", "Anzeigetext", "Grundpreis" },
                values: new object[] { 3, "BMW", 30000m });

            migrationBuilder.InsertData(
                table: "Options",
                columns: new[] { "Id", "Anzeigetext", "Preis" },
                values: new object[] { 1, "Klimaanlage", 2000m });

            migrationBuilder.InsertData(
                table: "Options",
                columns: new[] { "Id", "Anzeigetext", "Preis" },
                values: new object[] { 2, "Alufelgen", 1000m });

            migrationBuilder.InsertData(
                table: "Options",
                columns: new[] { "Id", "Anzeigetext", "Preis" },
                values: new object[] { 3, "Navigation", 500m });

            migrationBuilder.InsertData(
                table: "Options",
                columns: new[] { "Id", "Anzeigetext", "Preis" },
                values: new object[] { 4, "Subwoofer", 100m });

            migrationBuilder.InsertData(
                table: "Treibstoffe",
                columns: new[] { "Id", "Anzeigetext", "Umweltfreundlichkeitsklasse" },
                values: new object[] { 1, "Hybrid", 1 });

            migrationBuilder.InsertData(
                table: "Treibstoffe",
                columns: new[] { "Id", "Anzeigetext", "Umweltfreundlichkeitsklasse" },
                values: new object[] { 2, "Benzin", 2 });

            migrationBuilder.InsertData(
                table: "Treibstoffe",
                columns: new[] { "Id", "Anzeigetext", "Umweltfreundlichkeitsklasse" },
                values: new object[] { 3, "Diesel", 3 });

            migrationBuilder.InsertData(
                table: "Motoren",
                columns: new[] { "Id", "Anzeigetext", "Preis", "TreibstoffId" },
                values: new object[] { 1, "Benzin 1.6", 1500m, 2 });

            migrationBuilder.InsertData(
                table: "Motoren",
                columns: new[] { "Id", "Anzeigetext", "Preis", "TreibstoffId" },
                values: new object[] { 2, "Benzin 2.5", 5000m, 2 });

            migrationBuilder.InsertData(
                table: "Motoren",
                columns: new[] { "Id", "Anzeigetext", "Preis", "TreibstoffId" },
                values: new object[] { 3, "Diesel 1.8", 2000m, 3 });

            migrationBuilder.InsertData(
                table: "Motoren",
                columns: new[] { "Id", "Anzeigetext", "Preis", "TreibstoffId" },
                values: new object[] { 4, "Diesel 3.5", 4000m, 3 });

            migrationBuilder.InsertData(
                table: "Motoren",
                columns: new[] { "Id", "Anzeigetext", "Preis", "TreibstoffId" },
                values: new object[] { 5, "Hybrid 2.0 ", 6000m, 1 });

            migrationBuilder.CreateIndex(
                name: "IX_Bestellungen_HerstellerId",
                table: "Bestellungen",
                column: "HerstellerId");

            migrationBuilder.CreateIndex(
                name: "IX_Bestellungen_MotorId",
                table: "Bestellungen",
                column: "MotorId");

            migrationBuilder.CreateIndex(
                name: "IX_BestellungOptions_OptionId",
                table: "BestellungOptions",
                column: "OptionId");

            migrationBuilder.CreateIndex(
                name: "IX_Motoren_TreibstoffId",
                table: "Motoren",
                column: "TreibstoffId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BestellungOptions");

            migrationBuilder.DropTable(
                name: "Bestellungen");

            migrationBuilder.DropTable(
                name: "Options");

            migrationBuilder.DropTable(
                name: "Hersteller");

            migrationBuilder.DropTable(
                name: "Motoren");

            migrationBuilder.DropTable(
                name: "Treibstoffe");
        }
    }
}
